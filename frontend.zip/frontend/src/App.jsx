import React from 'react'

const App = () => {
  return (
    <>
      <header></header>
      <footer></footer>
    </>
  )
}

export default App